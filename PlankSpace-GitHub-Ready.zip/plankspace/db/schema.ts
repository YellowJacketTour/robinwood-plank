import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const posts = sqliteTable("posts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  author: text("author").notNull().default("PLANK"),
  authorWallet: text("author_wallet").notNull().default(""),
  body: text("body").notNull(),
  likes: integer("likes").notNull().default(0),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const comments = sqliteTable("comments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  postId: integer("post_id").notNull(),
  author: text("author").notNull().default("Anonymous Board"),
  body: text("body").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const profileComments = sqliteTable("profile_comments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  profileHandle: text("profile_handle").notNull(),
  author: text("author").notNull().default("Anonymous Board"),
  authorWallet: text("author_wallet").notNull().default(""),
  body: text("body").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
},table=>[index("profile_comments_handle_idx").on(table.profileHandle),index("profile_comments_author_time_idx").on(table.authorWallet,table.createdAt)]);

export const profileRelations = sqliteTable("profile_relations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ownerWallet: text("owner_wallet").notNull(),
  targetHandle: text("target_handle").notNull(),
  kind: text("kind").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
},table=>[uniqueIndex("profile_relations_unique").on(table.ownerWallet,table.targetHandle,table.kind)]);

export const postLikes = sqliteTable("post_likes", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  postId: integer("post_id").notNull(),
  wallet: text("wallet").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
},table=>[uniqueIndex("post_likes_unique").on(table.postId,table.wallet)]);

export const moderationLogs = sqliteTable("moderation_logs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  profileWallet: text("profile_wallet").notNull(),
  status: text("status").notNull(),
  note: text("note").notNull().default(""),
  moderatorWallet: text("moderator_wallet").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const profiles = sqliteTable("profiles", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  wallet: text("wallet").notNull().unique(),
  handle: text("handle").notNull().unique(),
  displayName: text("display_name").notNull(),
  bio: text("bio").notNull().default(""),
  hobbies: text("hobbies").notNull().default(""),
  interests: text("interests").notNull().default(""),
  music: text("music").notNull().default(""),
  heroes: text("heroes").notNull().default(""),
  lookingToMeet: text("looking_to_meet").notNull().default(""),
  avatarUrl: text("avatar_url").notNull().default(""),
  mood: text("mood").notNull().default("feeling board"),
  moodText: text("mood_text").notNull().default("holding down the lumberyard."),
  customHtml: text("custom_html").notNull().default(""),
  layoutJson: text("layout_json").notNull().default("[]"),
  featuredVideo: text("featured_video").notNull().default(""),
  moderationStatus: text("moderation_status").notNull().default("pending"),
  moderationNote: text("moderation_note").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const authChallenges = sqliteTable("auth_challenges", {
  nonce: text("nonce").primaryKey(),
  wallet: text("wallet").notNull(),
  action: text("action").notNull(),
  resource: text("resource").notNull(),
  payloadHash: text("payload_hash").notNull(),
  expiresAt: text("expires_at").notNull(),
},table=>[index("auth_challenges_wallet_idx").on(table.wallet),index("auth_challenges_expiry_idx").on(table.expiresAt)]);
