import { requireChatGPTUser } from "../chatgpt-auth";
/* eslint-disable @next/next/no-html-link-for-pages */
import OwnerAccessForm from "./owner-access-form";

export const dynamic = "force-dynamic";

export default async function OwnerAccess() {
  const user = await requireChatGPTUser("/owner-access");
  return <div className="onboard-shell"><header><a className="brand" href="/">plank<span>space</span><sup>β</sup></a><span>OWNER ACCESS</span></header><main className="onboard-card"><section><div className="onboard-plank"><i/><i/></div><small>TEST-SITE SHORTCUT</small><h1>Welcome back, DegenWaffle.</h1><p>Signed in as {user.email}. Enter your private test code to open your profile editor and admin controls without connecting or signing a wallet.</p><OwnerAccessForm/></section></main></div>;
}
