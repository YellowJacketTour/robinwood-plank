"use client";
import { FormEvent, useState } from "react";

export default function OwnerAccessForm() {
  const [code, setCode] = useState(""), [error, setError] = useState(""), [busy, setBusy] = useState(false);
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError("");
    const result = await fetch("/api/owner-access", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ code }) }).then((response) => response.json());
    if (result.authenticated) window.location.href = "/admin";
    else { setError(result.error || "Access denied"); setBusy(false); }
  };
  return <form onSubmit={submit} className="owner-access-form"><label>OWNER ACCESS CODE<input type="password" inputMode="numeric" autoComplete="one-time-code" value={code} onChange={(event) => setCode(event.target.value)} required autoFocus /></label><button disabled={busy}>{busy ? "Opening the woodshop…" : "Enter without wallet"}</button>{error && <strong>{error}</strong>}<p>This temporary test access works only for the signed-in PlankSpace owner.</p></form>;
}
