import { and, eq } from "drizzle-orm";
import { verifyMessage } from "viem";
import { getDb } from "../../../db";
import { authChallenges } from "../../../db/schema";

export type Proof = {wallet?:string;nonce?:string;message?:string;signature?:`0x${string}`;action?:string;resource?:string;payloadHash?:string};

export function authorizationMessage(wallet:string, action:string, resource:string, payloadHash:string, nonce:string, expiresAt:string) {
  return `PlankSpace authorization\nOrigin: https://plank.love\nChain: Robinhood Chain (4663)\nWallet: ${wallet}\nAction: ${action}\nResource: ${resource}\nPayload SHA-256: ${payloadHash}\nNonce: ${nonce}\nExpires: ${expiresAt}\n\nThis request does not authorize a transaction.`;
}

export async function verifyAndConsumeProof(proof:Proof, expectedAction:string, expectedResource:string, expectedHash:string) {
  const wallet=(proof.wallet||"").toLowerCase() as `0x${string}`;
  if(!/^0x[a-f0-9]{40}$/.test(wallet)||!proof.nonce||!proof.message||!proof.signature)return null;
  const db=getDb();
  const [challenge]=await db.select().from(authChallenges).where(and(eq(authChallenges.nonce,proof.nonce),eq(authChallenges.wallet,wallet))).limit(1);
  if(!challenge||Date.parse(challenge.expiresAt)<Date.now()||challenge.action!==expectedAction||challenge.resource!==expectedResource||challenge.payloadHash!==expectedHash)return null;
  const expected=authorizationMessage(wallet,expectedAction,expectedResource,expectedHash,challenge.nonce,challenge.expiresAt);
  if(proof.message!==expected||!await verifyMessage({address:wallet,message:expected,signature:proof.signature}))return null;
  const consumed=await db.delete(authChallenges).where(and(eq(authChallenges.nonce,challenge.nonce),eq(authChallenges.wallet,wallet))).returning({wallet:authChallenges.wallet});
  return consumed.length===1?wallet:null;
}
