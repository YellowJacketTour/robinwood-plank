import { desc, eq } from "drizzle-orm";
import { env } from "cloudflare:workers";
import { getDb } from "../../../db";
import { profiles } from "../../../db/schema";
import { hasOwnerSession, OWNER_WALLET } from "../../owner-access-auth";
import { hashJson } from "../auth/hash";
import { type Proof, verifyAndConsumeProof } from "../auth/verify";

const ADMIN_WALLET="0x269a93ec8486fbc3a82e352430e84fd8af8ebb0d";
const cleanHandle=(value:string)=>value.toLowerCase().replace(/[^a-z0-9_-]/g,"").slice(0,24);
const text=(value:unknown,max:number)=>typeof value==="string"?value.trim().slice(0,max):"";
const youtubeUrl=(value:unknown)=>{const raw=text(value,500);if(!raw)return "";try{const u=new URL(raw),host=u.hostname.replace(/^www\./,"");let id="";if(host==="youtu.be")id=u.pathname.slice(1).split("/")[0];else if(host==="youtube.com"||host==="m.youtube.com")id=u.searchParams.get("v")||(/^\/embed\//.test(u.pathname)?u.pathname.split("/")[2]:"");return /^[\w-]{6,20}$/.test(id)?`https://www.youtube.com/watch?v=${id}`:""}catch{return ""}};
const avatarUrl=(value:unknown)=>{const raw=text(value,500);if(!raw)return "";try{const u=new URL(raw);return u.protocol==="https:"?u.toString():""}catch{return ""}};
export const publicProfile=(p:typeof profiles.$inferSelect)=>({id:p.id,handle:p.handle,displayName:p.displayName,bio:p.bio,hobbies:p.hobbies,interests:p.interests,music:p.music,heroes:p.heroes,lookingToMeet:p.lookingToMeet,avatarUrl:p.avatarUrl?`/api/avatar?handle=${p.handle}`:"",mood:p.mood,moodText:p.moodText,customHtml:p.customHtml,layoutJson:p.layoutJson,featuredVideo:p.featuredVideo,createdAt:p.createdAt,updatedAt:p.updatedAt});

export async function GET(request:Request){
 const params=new URL(request.url).searchParams,handle=cleanHandle(params.get("handle")||""),availability=cleanHandle(params.get("availability")||"");
 const db=getDb();
 if(availability){const [match]=await db.select({id:profiles.id}).from(profiles).where(eq(profiles.handle,availability)).limit(1);return Response.json({available:!match})}
 if(handle){const [profile]=await db.select().from(profiles).where(eq(profiles.handle,handle)).limit(1);return profile?.moderationStatus==="approved"?Response.json({profile:publicProfile(profile)}):Response.json({error:"Profile not found"},{status:404})}
 const items=await db.select({handle:profiles.handle,displayName:profiles.displayName,bio:profiles.bio,avatarUrl:profiles.avatarUrl,mood:profiles.mood,updatedAt:profiles.updatedAt}).from(profiles).where(eq(profiles.moderationStatus,"approved")).orderBy(desc(profiles.updatedAt)).limit(100);
 return Response.json({profiles:items.map(p=>({...p,avatarUrl:p.avatarUrl?`/api/avatar?handle=${p.handle}`:""}))});
}

export async function PUT(request:Request){
 const payload=await request.json() as Proof&{wallet?:string};
 const wallet=(payload.wallet||"").toLowerCase(),hash=await hashJson({wallet});
 if(!await verifyAndConsumeProof(payload,"profile:read",wallet,hash))return Response.json({error:"Signed owner proof required"},{status:403});
 const [profile]=await getDb().select().from(profiles).where(eq(profiles.wallet,wallet)).limit(1);
 return profile?Response.json({profile}):Response.json({error:"Profile not found"},{status:404});
}

export async function POST(request:Request){
 const payload=await request.json() as Proof&{wallet?:string;handle?:string;profile?:Record<string,unknown>};
 const bypass=await hasOwnerSession(request),wallet=(payload.wallet||"").toLowerCase(),handle=cleanHandle(payload.handle||""),p=payload.profile||{};
 if(!/^0x[a-f0-9]{40}$/.test(wallet)||handle.length<3)return Response.json({error:"A valid wallet and 3–24 character username are required"},{status:400});
 if(bypass&&wallet!==OWNER_WALLET)return Response.json({error:"Owner shortcut is limited to DegenWaffle"},{status:403});
 const hash=await hashJson({handle,profile:p});
 if(!bypass&&!await verifyAndConsumeProof(payload,"profile:save",handle,hash))return Response.json({error:"Signed ownership proof does not match these profile changes"},{status:403});
 const db=getDb(),[existing]=await db.select().from(profiles).where(eq(profiles.wallet,wallet)).limit(1);
 if(existing&&existing.handle!==handle)return Response.json({error:"Usernames are permanent so profile links and comments never break"},{status:409});
 const [handleOwner]=await db.select().from(profiles).where(eq(profiles.handle,handle)).limit(1);
 if(handleOwner&&handleOwner.wallet!==wallet)return Response.json({error:"That username is already taken"},{status:409});
 let previousLayout:string[]=[];try{previousLayout=JSON.parse(existing?.layoutJson||"[]")}catch{}
 const layout=Array.isArray(p.layout)?p.layout.filter(v=>typeof v==="string").slice(0,20):previousLayout;
 let savedAvatar=avatarUrl(p.avatarUrl)||existing?.avatarUrl||"";const upload=typeof p.avatarData==="string"?p.avatarData:"",match=/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(upload);if(match){const bytes=Uint8Array.from(atob(match[2]),c=>c.charCodeAt(0));if(bytes.length>2_000_000)return Response.json({error:"Profile picture must be under 2 MB"},{status:413});const key=`avatars/${wallet}.${match[1]==="jpeg"?"jpg":match[1]}`;await (env as typeof env&{BUCKET:R2Bucket}).BUCKET.put(key,bytes,{httpMetadata:{contentType:`image/${match[1]}`}});savedAvatar=`r2:${key}`}
 const values={handle,displayName:text(p.displayName,40)||existing?.displayName||handle,bio:text(p.bio,500),hobbies:text(p.hobbies,500),interests:text(p.interests,500),music:text(p.music,500),heroes:text(p.heroes,500),lookingToMeet:text(p.lookingToMeet,500),avatarUrl:savedAvatar,mood:text(p.mood,40)||"feeling board",moodText:text(p.moodText,140)||"holding down the lumberyard.",customHtml:text(p.customHtml,20000),layoutJson:JSON.stringify(layout).slice(0,4000),featuredVideo:youtubeUrl(p.featuredVideo),moderationStatus:existing?.moderationStatus||(wallet===ADMIN_WALLET?"approved":"pending")};
 await db.insert(profiles).values({wallet,...values}).onConflictDoUpdate({target:profiles.wallet,set:{...values,updatedAt:new Date().toISOString()}});
 const [profile]=await db.select().from(profiles).where(eq(profiles.wallet,wallet)).limit(1);
 return Response.json({profile});
}
