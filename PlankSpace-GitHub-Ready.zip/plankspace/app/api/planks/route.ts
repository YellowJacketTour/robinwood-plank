import { eq } from "drizzle-orm";
/* eslint-disable prefer-const */
import { getDb } from "../../../db";
import { profiles } from "../../../db/schema";
const CONTRACT="0x327ceaaedbbcf55f40d6f1abc71bd9bc8adcb156";
type Scout={id?:string;image_url?:string|null;metadata?:{name?:string;image?:string;image_url?:string}|null;token?:{address_hash?:string;name?:string}};
const media=(v?:string|null)=>v?.startsWith("ipfs://")?`https://ipfs.io/ipfs/${v.slice(7)}`:v||null;
export async function GET(request:Request){
 const handle=(new URL(request.url).searchParams.get("handle")||"").toLowerCase().replace(/[^a-z0-9_-]/g,"").slice(0,24);if(!handle)return Response.json({items:[],error:"Profile required"},{status:400});
 try{const [profile]=await getDb().select({wallet:profiles.wallet,status:profiles.moderationStatus}).from(profiles).where(eq(profiles.handle,handle)).limit(1);if(!profile||profile.status!=="approved")return Response.json({items:[]},{status:404});let url=`https://robinhoodchain.blockscout.com/api/v2/addresses/${profile.wallet}/nft?type=ERC-721,ERC-1155`,all:Scout[]=[];for(let page=0;page<4&&url;page++){const res=await fetch(url,{headers:{accept:"application/json"},signal:AbortSignal.timeout(8000)});if(!res.ok)throw new Error();const data=await res.json() as {items?:Scout[];next_page_params?:Record<string,string|number>};all.push(...(data.items||[]));const n=data.next_page_params;url=n?`https://robinhoodchain.blockscout.com/api/v2/addresses/${profile.wallet}/nft?type=ERC-721,ERC-1155&${new URLSearchParams(Object.entries(n).map(([k,v])=>[k,String(v)])).toString()}`:""}const items=all.filter(i=>i.token?.address_hash?.toLowerCase()===CONTRACT).map(i=>({id:i.id||"?",name:i.metadata?.name||`RobinWood #${i.id||"?"}`,image:media(i.image_url||i.metadata?.image_url||i.metadata?.image),collection:i.token?.name||"RobinWoods"}));return Response.json({items},{headers:{"cache-control":"public, max-age=120"}})}catch{return Response.json({items:[],error:"Collection is temporarily unavailable"},{status:503})}
}
