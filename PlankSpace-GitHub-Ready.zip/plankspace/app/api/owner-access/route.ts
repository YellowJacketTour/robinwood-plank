import { clearOwnerSessionCookie, createOwnerSession, hasOwnerSession, ownerSessionCookie, OWNER_WALLET } from "../../owner-access-auth";

export async function GET(request: Request) {
  return Response.json({ authenticated: await hasOwnerSession(request), wallet: OWNER_WALLET });
}

export async function POST(request: Request) {
  const { code = "" } = await request.json() as { code?: string };
  const session = await createOwnerSession(request, code);
  if (!session) return Response.json({ error: "Access denied" }, { status: 403 });
  return Response.json({ authenticated: true, wallet: OWNER_WALLET }, { headers: { "Set-Cookie": ownerSessionCookie(session) } });
}

export async function DELETE() {
  return Response.json({ authenticated: false }, { headers: { "Set-Cookie": clearOwnerSessionCookie() } });
}
