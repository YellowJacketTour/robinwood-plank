import { desc, eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { moderationLogs, profiles } from "../../../../db/schema";
import { hasOwnerSession } from "../../../owner-access-auth";
import { hashJson } from "../../auth/hash";
import { type Proof, verifyAndConsumeProof } from "../../auth/verify";
const ADMIN="0x269a93ec8486fbc3a82e352430e84fd8af8ebb0d",statuses=new Set(["approved","pending","removed"]);
export async function POST(request:Request){
 const p=await request.json() as Proof&{action?:string;profileWallet?:string;status?:string;note?:string;wallet?:string},bypass=await hasOwnerSession(request),wallet=(p.wallet||"").toLowerCase();
 if(!bypass&&wallet!==ADMIN)return Response.json({error:"Admin wallet required"},{status:403});
 const db=getDb();
 if(bypass&&p.action==="owner-profile"){const [profile]=await db.select().from(profiles).where(eq(profiles.wallet,ADMIN)).limit(1);return Response.json({profile})}
 if(p.action!=="list"&&p.action!=="moderate")return Response.json({error:"Invalid admin action"},{status:400});
 const target=(p.profileWallet||"").toLowerCase(),status=p.status||"",note=(p.note||"").trim().slice(0,300),data=p.action==="list"?{action:"list"}:{action:"moderate",profileWallet:target,status,note};
 if(p.action==="moderate"&&(!/^0x[a-f0-9]{40}$/.test(target)||!statuses.has(status)))return Response.json({error:"Valid profile and status required"},{status:400});
 if(!bypass){const hash=await hashJson(data),resource=p.action==="list"?"admin":target;if(!await verifyAndConsumeProof(p,`admin:${p.action}`,resource,hash))return Response.json({error:"Signed admin authorization required"},{status:403})}
 if(p.action==="moderate"){await db.update(profiles).set({moderationStatus:status,moderationNote:note,updatedAt:new Date().toISOString()}).where(eq(profiles.wallet,target));await db.insert(moderationLogs).values({profileWallet:target,status,note,moderatorWallet:wallet||ADMIN})}
 return Response.json({profiles:await db.select().from(profiles).orderBy(desc(profiles.updatedAt)).limit(250)});
}
