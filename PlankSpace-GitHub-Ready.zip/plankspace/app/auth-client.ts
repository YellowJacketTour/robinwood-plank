import { ensurePlankLoveRobinhoodChain, signPlankLoveMessage } from "./plank-love-wallet";

export async function payloadHash(payload: unknown) {
  const bytes = new TextEncoder().encode(JSON.stringify(payload));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, "0")).join("");
}

export async function walletProof(wallet: string, action: string, resource: string, payload: unknown) {
  const state = await ensurePlankLoveRobinhoodChain(wallet);
  if (state.chainId !== 4663) throw new Error("Switch to Robinhood Chain before signing.");
  const hash = await payloadHash(payload);
  const challenge = await fetch("/api/auth/challenge", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ wallet, action, resource, payloadHash: hash }),
  }).then(r => r.json());
  if (!challenge.message || !challenge.nonce) throw new Error(challenge.error || "Could not create a signing request.");
  const signature = await signPlankLoveMessage(challenge.message, wallet);
  return { wallet, nonce: challenge.nonce, message: challenge.message, signature, action, resource, payloadHash: hash };
}
