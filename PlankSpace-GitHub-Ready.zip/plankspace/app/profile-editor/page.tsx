import ProfileForm from "../profile-form";
export default function ProfileEditor(){return <ProfileForm editing/>}
