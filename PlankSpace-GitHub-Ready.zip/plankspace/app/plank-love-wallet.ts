"use client";

const PLANKSPACE_SOURCE = "plankspace-wallet-v1";
const PLANK_LOVE_SOURCE = "plank-love-wallet-v1";

export type PlankLoveWalletState = {
  address: string | null;
  chainId: number | null;
  status: "disconnected" | "connecting" | "connected";
  isConnected: boolean;
};

type BridgeMethod =
  | "getState"
  | "connect"
  | "disconnect"
  | "ensureRobinhoodChain"
  | "signMessage";

type BridgeResponse = {
  source: typeof PLANK_LOVE_SOURCE;
  type: "wallet:response";
  requestId: string;
  result?: { state?: PlankLoveWalletState; signature?: string; address?: string };
  error?: string;
};

type BridgeStateMessage = {
  source: typeof PLANK_LOVE_SOURCE;
  type: "wallet:state";
  state: PlankLoveWalletState;
};

const pending = new Map<
  string,
  {
    resolve: (value: NonNullable<BridgeResponse["result"]>) => void;
    reject: (error: Error) => void;
    timeout: ReturnType<typeof setTimeout>;
  }
>();

let initialized = false;
let parentOrigin: string | null = null;
let state: PlankLoveWalletState = {
  address: null,
  chainId: null,
  status: "disconnected",
  isConnected: false,
};

function resolveParentOrigin() {
  if (typeof window === "undefined" || window.parent === window || !document.referrer) return null;
  try {
    const origin=new URL(document.referrer).origin,host=new URL(origin).hostname;
    if(host!=="plank.love"&&!host.endsWith(".plank.love")&&!host.endsWith(".chatgpt.site"))return null;
    return origin;
  } catch {
    return null;
  }
}

function isBridgeMessage(value: unknown): value is BridgeResponse | BridgeStateMessage {
  if (!value || typeof value !== "object") return false;
  const message = value as Partial<BridgeResponse | BridgeStateMessage>;
  return message.source === PLANK_LOVE_SOURCE &&
    (message.type === "wallet:response" || message.type === "wallet:state");
}

function startBridge() {
  if (initialized || typeof window === "undefined") return;
  initialized = true;
  parentOrigin = resolveParentOrigin();
  if (!parentOrigin) return;

  window.addEventListener("message", (event: MessageEvent<unknown>) => {
    if (event.source !== window.parent || event.origin !== parentOrigin || !isBridgeMessage(event.data)) {
      return;
    }
    const message = event.data;
    if (message.type === "wallet:state") {
      state = message.state;
      return;
    }
    const request = pending.get(message.requestId);
    if (!request) return;
    clearTimeout(request.timeout);
    pending.delete(message.requestId);
    if (message.error) request.reject(new Error(message.error));
    else request.resolve(message.result || {});
  });

  window.parent.postMessage(
    { source: PLANKSPACE_SOURCE, type: "wallet:ready" },
    parentOrigin
  );
}

function requireBridgeOrigin() {
  startBridge();
  if (!parentOrigin) {
    throw new Error("Open PlankSpace from the Plank.love tab to use its wallet connection.");
  }
  return parentOrigin;
}

async function requestWallet(
  method: BridgeMethod,
  payload?: { address?: string; message?: string }
) {
  const origin = requireBridgeOrigin();
  const requestId = crypto.randomUUID();
  const waitMs = method === "connect" || method === "signMessage" ? 120_000 : 30_000;
  return new Promise<NonNullable<BridgeResponse["result"]>>((resolve, reject) => {
    const timeout = setTimeout(() => {
      pending.delete(requestId);
      reject(new Error("Plank.love did not finish the wallet request. Try again."));
    }, waitMs);
    pending.set(requestId, { resolve, reject, timeout });
    window.parent.postMessage(
      { source: PLANKSPACE_SOURCE, type: "wallet:request", requestId, method, payload },
      origin
    );
  });
}

export async function getPlankLoveWalletState() {
  const result = await requestWallet("getState");
  if (result.state) state = result.state;
  return state;
}

export async function connectPlankLoveWallet() {
  const result = await requestWallet("connect");
  if (result.state) state = result.state;
  if (!state.address) throw new Error("Plank.love did not return a connected wallet.");
  return state.address.toLowerCase();
}

export async function ensurePlankLoveRobinhoodChain(address?: string) {
  const result = await requestWallet("ensureRobinhoodChain", { address });
  if (result.state) state = result.state;
  return state;
}

export async function signPlankLoveMessage(message: string, address: string) {
  if(!message.startsWith("PlankSpace authorization\n")||message.length>2000)throw new Error("PlankSpace rejected an unknown signing request.");
  const result = await requestWallet("signMessage", { message, address });
  if (!result.signature) throw new Error("Plank.love did not return a signature.");
  return result.signature;
}

export async function disconnectPlankLoveWallet() {
  const result = await requestWallet("disconnect");
  if (result.state) state = result.state;
  return state;
}

startBridge();
