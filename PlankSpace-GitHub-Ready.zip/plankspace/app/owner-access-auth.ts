import { env } from "cloudflare:workers";

const COOKIE_NAME = "plankspace_owner_session";
const OWNER_WALLET = "0x269a93ec8486fbc3a82e352430e84fd8af8ebb0d";
const SESSION_SECONDS = 60 * 60 * 8;
const runtimeEnv = env as typeof env & { PLANKSPACE_OWNER_EMAIL?: string; PLANKSPACE_OWNER_ACCESS_CODE?: string; PLANKSPACE_OWNER_SESSION_SECRET?: string };

function ownerEmail() {
  return String(runtimeEnv.PLANKSPACE_OWNER_EMAIL || "").trim().toLowerCase();
}

function accessCode() {
  return String(runtimeEnv.PLANKSPACE_OWNER_ACCESS_CODE || "");
}

function sessionSecret(){return String(runtimeEnv.PLANKSPACE_OWNER_SESSION_SECRET||"")}

function requestEmail(request: Request) {
  return (request.headers.get("oai-authenticated-user-email") || "").trim().toLowerCase();
}

function bytesToHex(bytes: Uint8Array) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

async function sign(value: string) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(sessionSecret()||accessCode()),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return bytesToHex(new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value))));
}

function cookieValue(request: Request) {
  const cookies = request.headers.get("cookie") || "";
  return cookies.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${COOKIE_NAME}=`))?.slice(COOKIE_NAME.length + 1) || "";
}

async function equal(a:string,b:string){const x=new TextEncoder().encode(a),y=new TextEncoder().encode(b);if(x.length!==y.length)return false;let diff=0;for(let i=0;i<x.length;i++)diff|=x[i]^y[i];return diff===0}
export async function createOwnerSession(request: Request, submittedCode: string) {
  const email = requestEmail(request);
  if (!email || email !== ownerEmail() || !accessCode() || !await equal(submittedCode,accessCode())) return null;
  const expires = Math.floor(Date.now() / 1000) + SESSION_SECONDS;
  const payload = `${email}:${expires}`;
  return `${expires}.${await sign(payload)}`;
}

export async function hasOwnerSession(request: Request) {
  const email = requestEmail(request);
  if (!email || email !== ownerEmail() || !accessCode()) return false;
  const token = cookieValue(request);
  const [expiresRaw, signature] = token.split(".");
  const expires = Number(expiresRaw);
  if (!Number.isFinite(expires) || expires < Math.floor(Date.now() / 1000) || !signature) return false;
  return signature === await sign(`${email}:${expiresRaw}`);
}

export function ownerSessionCookie(value: string) {
  return `${COOKIE_NAME}=${value}; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=${SESSION_SECONDS}`;
}

export function clearOwnerSessionCookie() {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

export { OWNER_WALLET };
