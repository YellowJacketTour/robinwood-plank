import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("build emits a deployable worker and PlankSpace metadata",async()=>{
 const [worker,manifest,layout]=await Promise.all([
  readFile(new URL("../dist/server/index.js",import.meta.url),"utf8"),
  readFile(new URL("../dist/.openai/hosting.json",import.meta.url),"utf8"),
  readFile(new URL("../app/layout.tsx",import.meta.url),"utf8"),
 ]);
 assert.match(worker,/export\s*\{[^}]*default/);
 assert.equal(JSON.parse(manifest).d1,"DB");
 assert.match(layout,/title:\{default:"PlankSpace"/);
 assert.doesNotMatch(layout,/codex-preview/);
});

test("worker applies browser security headers",async()=>{
 const worker=await readFile(new URL("../worker/index.ts",import.meta.url),"utf8");
 assert.match(worker,/X-Content-Type-Options/);
 assert.match(worker,/frame-ancestors https:\/\/plank\.love/);
 assert.match(worker,/Permissions-Policy/);
});
